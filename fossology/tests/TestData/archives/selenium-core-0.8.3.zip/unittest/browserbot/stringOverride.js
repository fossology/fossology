String.prototype.sayHello = function() {
    return "Hello, " + this;
}