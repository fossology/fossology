Selenium.version = "0.8.3";
Selenium.revision = "1879";

window.top.document.title += " v" + Selenium.version + " [" + Selenium.revision + "]";

